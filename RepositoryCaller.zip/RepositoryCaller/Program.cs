﻿using System;
using System.Collections.Generic;
using ProcessorClass;

namespace RepositoryCaller
{
    class Program
    {
        static void Main(string[] args)
        {
            //using constructor
            ProcessorAction pa = new ProcessorAction();

            //variable to become parameter
            String inputFile;
            String dataContent;
            
            //path file and filename
            //inputFile = "d:\\product.json"; 
            inputFile = "d:\\product.xml";

            int tof = pa.GetType(inputFile); //type of file (tof)
            if (tof == 1)
            {
                dataContent = pa.GetContentFileJSON(inputFile);
                Console.WriteLine("Content of json file: "+dataContent);
                pa.Register(inputFile, dataContent, tof);
            }
            else if (tof == 2)
            {
                dataContent = pa.GetContentFileXML(inputFile);
                Console.WriteLine("Content of xml file: " + dataContent);
                pa.Register(inputFile, dataContent, tof);
            }
            //test the method to Retrieve the data
            pa.Retrieve(inputFile);
            
            //test the method to Remove/Deregister the data
            //after data was removed, it could be checked by retrieve the deleted filename
            pa.Deregister(inputFile);
            pa.Retrieve(inputFile);
        }
    }
}
