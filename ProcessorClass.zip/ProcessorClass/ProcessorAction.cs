﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;

namespace ProcessorClass
{
    public class ProcessorAction
    {
        private ISubRepository repository;
        private Product prodDetail = new Product();
        private JObject object_json = new JObject();
        private XmlDocument xmlDoc = new XmlDocument();
        private XmlNodeList nodeList;
        private string methodResult = null;
        private string dataContent = null;
        
        //this method to register repository 
        //itemContent will be get from GetContentFileJSON/GetContentFileXML method 
        public void Register(string itemName, string itemContent, int itemType) 
        {
            if ((itemType == 1) && (itemName.Contains("json") == true))
            {
                try {
                    prodDetail = JsonConvert.DeserializeObject<Product>(itemContent);
                } 
                
                catch (Exception ex){
                    Console.WriteLine(ex.Message);
                }
                
            }
            else if ((itemType == 2) && (itemName.Contains("xml") == true))
            {
                try
                {
                    //nodeList get value from xmlDoc variable
                    nodeList = xmlDoc.DocumentElement.SelectNodes("/Table/Product");
                    foreach (XmlNode node in nodeList)
                    {
                        prodDetail.id = int.Parse(node.SelectSingleNode("id").InnerText);
                        prodDetail.brand = node.SelectSingleNode("brand").InnerText;
                        prodDetail.model = node.SelectSingleNode("model").InnerText;
                        prodDetail.solution = node.SelectSingleNode("solution").InnerText;
                    }
            
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
            else
            {
                Console.WriteLine("Only support for JSON file or XML file. Please check the file.");
            }
            //insert content of file into repository
            repository = new ISubChildRepository();
            repository.AddInRepo(prodDetail);

            Console.WriteLine("Register complete from file, with ID: " + prodDetail.id);

        }

        //retrieve an item from repository
        public string Retrieve(string itemName) {
            try {
                //string retresult = null;
                if (GetType(itemName) == 1)
                {
                    dataContent = GetContentFileJSON(itemName);
                }
                else if (GetType(itemName) == 2)
                {
                    dataContent = GetContentFileXML(itemName);
                }
                var getproduct = repository.GetById(prodDetail.id);
                methodResult = "Retrieve based on file - Id: " + getproduct.id + ", brand: " + getproduct.brand;
                Console.WriteLine(methodResult);
            } 
            catch (Exception ex){
                Console.WriteLine(ex.Message);
            }
            
            return methodResult;
        }

        //get type of item JSON or XML
        public int GetType(string itemName) {
            int check = 0; //JSON is true
            if (itemName.Contains("json") == true)
            {
                check = 1;
            }
            else if (itemName.Contains("xml") == true)
            {
                check = 2;
            }
            else
            {
                check = 0;
            }
            return check;
        }

        //remove an item from repository
        public void Deregister(string itemName) {
            if (GetType(itemName) == 1)
            {
                dataContent = GetContentFileJSON(itemName);
                var rmproduct = repository.GetById(prodDetail.id);
                repository.RemoveFromRepo(rmproduct);
            }
            else if (GetType(itemName) == 2) {
                dataContent = GetContentFileXML(itemName);
                var rmproduct = repository.GetById(prodDetail.id);
                repository.RemoveFromRepo(rmproduct);
            }
        }

        public string GetContentFileJSON(string itemName) {
            //get content file of JSON
            String cf_json = null;
            try
            {
                //convert json file
                JObject object_json = JObject.Parse(File.ReadAllText(itemName));
                cf_json = object_json.ToString();
            }
            catch (Newtonsoft.Json.JsonReaderException jsonex)
            {
                Console.WriteLine(jsonex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return cf_json;
        }

        public string GetContentFileXML(string itemName) {
            // Load the xml file into XmlDocument object.
            try
            {
                xmlDoc.Load(itemName);
            }
            catch (XmlException e)
            {
                Console.WriteLine(e.Message);
            }
            // Now create StringWriter object to get data from xml document.
            StringWriter sw = new StringWriter();
            XmlTextWriter xw = new XmlTextWriter(sw);
            xmlDoc.WriteTo(xw);
            return sw.ToString();
        }

        public void initialize()
        {
            //this method leave empty 
            //main caller another method
        }
    
    }
}
