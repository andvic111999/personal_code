﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProcessorClass
{
    public interface ISubRepository : IUniversalRepository<Product>
    {
        Product GetById(int id);
        void AddInRepo(Product product);
        void RemoveFromRepo(Product product);
    }
}
