﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProcessorClass
{
    //entity for product
    public class Product
    {
        public int id { get; set; }
        public string brand { get; set; }
        public string model { get; set; }
        public string solution { get; set; }
       
      
    }
}
