﻿using System.Collections.Generic;
using System.Linq;

namespace ProcessorClass
{
    //interface formulatrix (or ftix) repository
    public interface IUniversalRepository<TEntity> where TEntity : class
    {
        TEntity GetById(int id);
        void AddInRepo(TEntity entity);
        void RemoveFromRepo(TEntity entity);
    }

}