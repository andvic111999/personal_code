﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace ProcessorClass
{
    public class ISubChildRepository : ISubRepository
    {
        private readonly Dictionary<int, Product> dictionary;

        public ISubChildRepository()
        {
            dictionary = new Dictionary<int, Product>();
        }

        public void AddInRepo(Product product)
        {
            dictionary.Add(product.id, product);
        }

        public Product GetById(int id)
        {
            return dictionary[id];
        }

        public void RemoveFromRepo(Product product)
        {
            dictionary.Remove(product.id);
        }

    }      

}
